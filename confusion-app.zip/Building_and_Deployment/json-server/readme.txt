npm install json-server -g
json-server --watch db.json
//to introduce delay artifically 2 sec
json-server --watch db.json -d 2000